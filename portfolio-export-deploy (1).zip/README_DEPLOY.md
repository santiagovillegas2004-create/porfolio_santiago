# Cómo publicar tu portafolio sin que cambie el diseño

Este paquete está listo para publicarse tal cual y que se vea igual que la maqueta.

## Opción A — GitHub Pages (gratis)
1. Crea un repositorio nuevo en GitHub (p.ej. `portfolio`).
2. **Sube TODOS** los archivos y carpetas de este ZIP a la raíz del repo (incluido `.nojekyll`).
3. Ve a *Settings → Pages*.
4. En **Source**, elige **Deploy from a branch**.
5. Selecciona **branch: main** y **/ (root)**, guarda.
6. Espera a que GitHub cree la URL pública de Pages. Abre la URL y verifica.

> `.nojekyll` evita que GitHub aplique Jekyll y asegura que los archivos se sirvan tal cual.

## Opción B — Netlify (gratis)
1. Entra a https://app.netlify.com y haz **Add new site → Deploy manually**.
2. Arrastra y suelta **el contenido de este ZIP** tal cual (no la carpeta padre).
3. Netlify leerá `netlify.toml` y publicará directamente.

## Comprobaciones
- Abre `index.html` en la URL publicada y verifica los enlaces a PDFs y vídeos.
- Si cambiaste el usuario de LinkedIn, recuerda modificarlo en `index.html`.
- Reemplaza los placeholders en `projects/…` por tus archivos reales antes de subir.

Cualquier ajuste que necesites, dímelo y te genero un nuevo paquete listo para subir.
